斗鱼直播 for XBMC
================

v2.0
fixed play, code based on HexPang, thx




截图
----------------
![img](https://github.com/HexPang/DouyuLiveForXBMC/raw/master/Screenshot/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7%202014-08-31%2015.48.30.png "截图01")

![img](https://github.com/HexPang/DouyuLiveForXBMC/raw/master/Screenshot/%E5%B1%8F%E5%B9%95%E5%BF%AB%E7%85%A7%202014-08-31%2015.48.06.png "截图02")

说明
----------------
> 针对XBMC开发的插件,界面待优化.欢迎探讨.

> 之前没接触过Python,代码较渣,请谅解.

下载
----------------
1. v1.0.1-2014-08-31 [下载](https://github.com/HexPang/DouyuLiveForXBMC/archive/v1.0.1.zip)

更新内容
----------------
1. 暂无
