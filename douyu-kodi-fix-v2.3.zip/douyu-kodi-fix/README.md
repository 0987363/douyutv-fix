斗鱼直播 for XBMC
================

v2.3
fixed some bug

v2.2
fixed play, 2015.10.29

v2.1
add list room by online, and remove unused code

v2.0
fixed play, code based on HexPang@github.com/HexPang/DouyuLiveForXBMC, thanks




old version:

说明
----------------
> 针对XBMC开发的插件,界面待优化.欢迎探讨.

> 之前没接触过Python,代码较渣,请谅解.

下载
----------------
1. v1.0.1-2014-08-31 [下载](https://github.com/HexPang/DouyuLiveForXBMC/archive/v1.0.1.zip)

更新内容
----------------
1. 暂无
